#i have created this file-mehak
from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request,'index.html')


def analyze(request):
    djtext = request.POST.get('text','default')
    removepunc = request.POST.get('removepunc', 'off')
    uppercase = request.POST.get('uppercase','off')
    newlinerremover = request.POST.get('newlinerremover','off')
    removespace = request.POST.get('removespace','off')
    countchr = request.POST.get('countchr','off')
    

    
    if(removepunc == "on"):
        punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        analyze=""
        for char in djtext:
            if char not in punctuations:
                analyze = analyze + char
        params={'purpose' : 'remove punchuations','analyzed_text':analyze}
        #return render(request,'analyze.html',params)
        djtext = analyze
   

    if(uppercase == "on"):
        analyze=""
        for char in djtext:
            analyze = analyze + char.upper()
        params={'purpose' : 'change to UPPERCASE ','analyzed_text':analyze}
        djtext = analyze
        #return render(request,'analyze.html',params)
       
    
    
    if(newlinerremover == "on"):
        analyze=""
        analyze = djtext.replace("\n", " ").replace("\r", "")
        params={'purpose' : 'remove new line  ','analyzed_text':analyze}
        djtext = analyze
        #return render(request,'analyze.html',params)
   

    
    if(removespace == "on"):
        analyze=""
        for index,char in enumerate(djtext):
            if  not(djtext[index] == " " and djtext[index + 1] == " "):
                analyze = analyze + char
        params={'purpose' : 'remove extra space ','analyzed_text':analyze}
        djtext = analyze
        #return render(request,'analyze.html',params)
        
    

    if(countchr == "on"):
        count = 0
        for char in djtext:
            if char != " ":
                count = count + 1
        params={'purpose' : 'countchar','analyzed_text':analyze,'chr_count':count,'show_count': True}
        
        #return render(request,'analyze.html',params) 
    return render(request,'analyze.html',params)   
   
    
